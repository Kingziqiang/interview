//为我们的表格排序准备json格式的数据
//sex:0->男 1->女
var jsonAry = [
    {"name": "赵老大", "age": 45, "score": 89, "sex": 0},
    {"name": "钱二妞", "age": 24, "score": 67, "sex": 1},
    {"name": "孙三娘", "age": 38, "score": 79, "sex": 1},
    {"name": "李四爷", "age": 30, "score": 80, "sex": 0},
    {"name": "周姑娘", "age": 65, "score": 56, "sex": 1},
    {"name": "吴三桂", "age": 26, "score": 26, "sex": 0}
];